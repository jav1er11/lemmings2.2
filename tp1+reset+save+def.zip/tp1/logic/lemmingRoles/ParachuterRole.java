package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;
import tp1.view.Messages;

public class ParachuterRole extends AbstractRole {
	private static final String name = Messages.PARACHUTER_ROL_NAME;
	private static final String help = Messages.PARACHUTER_ROL_HELP;
	private static final String symbol = Messages.PARACHUTER_ROL_SYMBOL;
	
	
	public ParachuterRole() {
		super(name,symbol,help);
	}
	public void start( Lemming lemming ) {
		lemming.setFuerza0();;	
    }
 	
    public void play( Lemming lemming ) {
    	this.start(lemming);
		lemming.walkOrFall();	
    }
    public String getIcon( Lemming lemming ) {
    	return Messages.LEMMING_PARACHUTE;
    }

    public void incFuerzaCaida(Lemming lemming) {
		lemming.setFuerza0();
	}
    public boolean noSobrevive(Lemming lemming) {
		return false;
	}

	@Override
	public boolean equals(LemmingRole role) {
		return role.getName().equals(this.name);
	}
	@Override
	public void setWalkerRole(Lemming lemming) {
		if(!lemming.isInAir()) {
			lemming.setWalker();
		}
	}
    
}
