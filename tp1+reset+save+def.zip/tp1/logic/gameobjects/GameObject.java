package tp1.logic.gameobjects;
import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.view.Messages;

public abstract class GameObject implements GameItem {

	protected Position pos;
	protected boolean isAlive;
	protected GameWorld game;
	protected String nombre;

	
	public GameObject(GameWorld game, Position pos) {
		this.isAlive = true;
		this.pos = pos;
		this.game = game;
	}
	protected GameObject(String nombre) {
		this.nombre=nombre;
	}
	public boolean isInPosition(Position p) {
		return this.pos.equals(p)&&this.isAlive;
	}
 	
	public boolean isAlive() {
		return isAlive;
	}
	public void muere() {
		this.isAlive=false;
	}
	public boolean setRole(LemmingRole role, Position pos) {
		return false;
	}
	public abstract boolean isSolid();
	 
	 public boolean isExit() {
		return false;
	 }
	 public boolean haAcabado() {
			return false;
	 }
	public abstract void update();
	
	public abstract String getIcon();
	
	public  abstract boolean receiveInteraction(GameItem other);

	public boolean interactWith(Lemming lemming) {
		return false;
	}
	public boolean interactWith(Pared wall) {
		return false;
	}
	public boolean interactWith(ExitDoor door) {
		return false;
	}
	@Override
	public abstract String toString();
	protected boolean matchObjectName(String name) {
		return	this.nombre.equalsIgnoreCase(name);
	}
	public boolean matchName(String ob) {
		return this.nombre.equalsIgnoreCase(ob);
	}
	public Position getPosDeString (String line) throws ObjectParseException {
		try {
		String aux=line;
		aux= aux.replace(')', ' ');
		aux= aux.replace(',', ' ');
		aux= aux.replace('(', ' ');
		String positionString[];
		positionString= aux.trim().split("\s+");
		if(positionString.length==2) {
			int col=Integer.parseInt(positionString[1]);
			int pos=Integer.parseInt(positionString[0]);
			return new Position(col,pos);
		}
		else {
			throw new ObjectParseException(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);
		}
		}catch(NumberFormatException e){
			throw new ObjectParseException("Invalid object position: ", e);
		}
	}

	public abstract GameObject parse(String line, GameWorld game) throws ObjectParseException, OffBoardException;
}

