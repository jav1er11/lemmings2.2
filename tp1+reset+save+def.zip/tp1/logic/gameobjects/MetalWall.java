package tp1.logic.gameobjects;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.view.Messages;

public class MetalWall extends GameObject {

	public MetalWall(GameWorld game, Position pos) {
		super(game, pos);
	}
	@Override
	public boolean isSolid() {
		return true;
	}

	@Override
	public void update() {
		
	}
	protected MetalWall()
	{
		super("MetalWall");
	}
	@Override
	public String getIcon() {
		return Messages.METALWALL;
	}
	@Override
	public boolean receiveInteraction(GameItem other) {
		return false;
	}
	@Override
	public  String toString() {
		return this.pos.toString()+" MetalWall";
	}
	@Override
	public GameObject parse(String line, GameWorld game) throws ObjectParseException, OffBoardException{
		String objeto [] = line.trim().split("\s+"); 
	    MetalWall mw=null;
	    if(objeto.length==2&& this.matchObjectName(objeto[1])) {
	    	Position pos = this.getPosDeString(objeto[0]);
	    	if(pos.fueraTablero()) {
	    		throw new OffBoardException("Object position is offboard ");
	    	}
	    	else {
	    		mw=  new MetalWall(game,pos); 
	    	}	
	    }
	    return mw; 
	}
}
