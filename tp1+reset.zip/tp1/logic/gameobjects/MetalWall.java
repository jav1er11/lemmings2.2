package tp1.logic.gameobjects;

import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.view.Messages;

public class MetalWall extends GameObject {

	public MetalWall(GameWorld game, Position pos) {
		super(game, pos);
	}

	@Override
	public boolean isSolid() {
		return true;
	}

	@Override
	public void update() {
		
	}

	@Override
	public String getIcon() {
		return Messages.METALWALL;
	}
	@Override
	public boolean receiveInteraction(GameItem other) {
		return false;
	}
	@Override
	public  String toString() {
		return "metalWall "+this.pos.toString();
	}

}
