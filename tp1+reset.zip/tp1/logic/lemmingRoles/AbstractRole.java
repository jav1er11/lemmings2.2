package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Pared;

public abstract class AbstractRole implements LemmingRole {
	 private final String NAME;
	 private final String SYMBOL;
	 private final String HELP;
	
	 public AbstractRole(String name, String symbol,  String help) {
			this.NAME = name;
			this.SYMBOL =symbol;
			this.HELP = help;
		}
	 public String getName() { return NAME; }
	 
	protected String getSymbol() { return SYMBOL; }
	
	protected String getHelp() { return HELP; }
	 
	 public abstract void play( Lemming lemming );
	 public abstract String getIcon( Lemming lemming );
	 
	 protected boolean matchRoleName(String name) {
			return getSymbol().equalsIgnoreCase(name) || 
					getName().equalsIgnoreCase(name);
	}
	 
	public AbstractRole parse(String input) {
		AbstractRole com=null;
		if(this.matchRoleName(input)) {
			com=this;
		}
		return com;
	} 
	 public abstract void incFuerzaCaida(Lemming lemming);
	 public  boolean noSobrevive(Lemming lemming) {
				return lemming.noVive();
	 }
	 public boolean equals(LemmingRole role) {
			return role.getName().equals(this.NAME);
		};
		
	public boolean interactWith(Pared wall,Lemming lemming) {
			return false;
	}
	public void setWalkerRole(Lemming lemming) {
			 
	}
	@Override
	public  String toString() {
		return this.SYMBOL;
	}

}
