
package tp1.logic;

import tp1.logic.lemmingRoles.LemmingRole;

public interface GameModel {
	public void initGame1();
	public void initGame0();
	public void initGame(int nLevel);
	public void update();
	public int getLevel();
	public void exit();
	public boolean isFinished();
	boolean roleCambiar(Position pos, LemmingRole rol);
}
