package tp1.control.commands;

import tp1.logic.GameModel;
import tp1.view.GameView;
import tp1.view.Messages;

public abstract class Command {

	// Forman parte de atributos de estado
	private final String NAME;
	private final String SHORTCUT;
	private final String DETAILS;
	private final String HELP;
	
	public Command(String name, String shorcut, String details, String help) {
		this.NAME = name;
		this.SHORTCUT = shorcut;
		this.DETAILS = details;
		this.HELP = help;
	}

	protected String getName() { return NAME; }
	protected String getShortcut() { return SHORTCUT; }
	protected String getDetails() { return DETAILS; }
	protected String getHelp() { return HELP; }

	public abstract void execute(GameModel game, GameView view);	  
	public abstract Command parse(String[] commandWords);

	protected boolean matchCommandName(String name) {
		return getShortcut().equalsIgnoreCase(name) || 
				getName().equalsIgnoreCase(name);
	}

	public String helpText(){
		return Messages.LINE_TAB.formatted(Messages.COMMAND_HELP_TEXT.formatted(getDetails(), getHelp()));
	}
	@Override
	public String toString() {
		return "Command"+NAME;
	}
}
