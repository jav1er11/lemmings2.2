package tp1.control.commands;

import tp1.logic.GameModel;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.ConsoleView;
import tp1.view.GameView;
import tp1.view.Messages;

public class SetRoleCommand extends Command {

    private static final String NAME = Messages.COMMAND_SETROLE_NAME;
    private static final String SHORTCUT = Messages.COMMAND_SETROLE_SHORTCUT;
    private static final String DETAILS = Messages.COMMAND_SETROLE_DETAILS;
    private static final String HELP = Messages.COMMAND_SETROLE_HELP;
    private static final String ERROR = 
    "SetRoleCommand error (Incorrect position or no object in that position admits that role)";

    
    private LemmingRole role;
    private Position pos;
    
	public SetRoleCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}
	@Override
	public Command parse(String[] commandWords) {
		Command com=null;
		if(this.matchCommandName(commandWords[0])&&commandWords.length==4) {						
			this.role= LemmingRoleFactory.parse(commandWords[1]);
			if(this.role!=null) {
				this.pos = 
				new Position(ConsoleView.colNameToNum(commandWords[3]),
				Integer.parseInt(ConsoleView.rowNameToNum(commandWords[2].toUpperCase())));
				com=this;	
			}
		}
		return com;
	}
	@Override
	public void execute(GameModel game, GameView view) {
		
		if(game.roleCambiar(this.pos, this.role)) {
			game.update();
			view.showGame();
		}
		else {
			view.showError(this.ERROR);
		}
		
		
	}

}
