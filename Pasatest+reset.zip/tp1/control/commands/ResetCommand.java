package tp1.control.commands;

import java.util.Arrays;
import java.util.List;

import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.ConsoleView;
import tp1.view.GameView;
import tp1.view.Messages;

public class ResetCommand extends Command {

    private static final String NAME = Messages.COMMAND_RESET_NAME;
    private static final String SHORTCUT = Messages.COMMAND_RESET_SHORTCUT;
    private static final String DETAILS = Messages.COMMAND_RESET_DETAILS;
    private static final String HELP = Messages.COMMAND_RESET_HELP;
    private static final String ERROR = "Not valid level number";

    
    private String nlvl;
    private boolean sinparam;
    private static final List<String> AVAILABLELVLS= Arrays.asList(
			"0",
			"1",
			"2"		
	);
    
    public ResetCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
		if(sinparam) {
		game.initGame(game.getLevel());
		view.showGame();
		}
		else {
			if(this.comprobarNivel()) {
				game.initGame(Integer.parseInt(this.nlvl));
				view.showGame();
			}
			else {
				view.showError(ERROR);
			}
			
		}
		
	}

	@Override
	public Command parse(String[] commandWords) {
		Command com=null;
		if(this.matchCommandName(commandWords[0])&&commandWords.length==1){
		sinparam=true;
		com=this;
		}
		else if(this.matchCommandName(commandWords[0])&&commandWords.length==2) {
		nlvl= 	commandWords[1];
		sinparam=false;
		com=this;
		}
		return com;
		
	}
	private boolean comprobarNivel() {
		for (String c: AVAILABLELVLS) {
			if(c.equals(this.nlvl)) {
				return true;
			}
		}
		return false;
	}
	
}

