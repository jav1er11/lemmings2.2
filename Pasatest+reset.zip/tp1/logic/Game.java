package tp1.logic;

import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.MetalWall;
import tp1.logic.gameobjects.Pared;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.ParachuterRole;
import tp1.logic.lemmingRoles.WalkerRole;

public class Game implements GameStatus, GameWorld, GameModel {
	private int numLemmings;
	private int cycle;
	private int level;
	private boolean exit;
	public static final int DIM_X = 10;
	public static final int DIM_Y = 10;
	private  int lemmingsSalida ;
	private  int lemmingsMuertos ;
	private int lemmings_win;
	private GameObjectContainer container;
	
	public Game(int nLevel) {
		this.container= new GameObjectContainer();
		this.level= nLevel;
		this.initGame(nLevel);
		lemmingsSalida=0 ;
		this.exit=false;
	}
	
// GameStatus methods
	@Override
	public int getCycle() {
		return this.cycle;
	}

	@Override
	public int numLemmingsInBoard() {
				return this.numLemmings;
	}

	@Override
	public int numLemmingsDead() {
		return this.lemmingsMuertos;
	}

	@Override
	public int numLemmingsExit() {
		return this.lemmingsSalida;
	}

	@Override
	public int numLemmingsToWin() {
		return lemmings_win;
	}

	@Override
	public String positionToString(int col, int row) {
		String dibujo;
		Position pos= new Position(col,row);
		dibujo= this.container.iconoPos(pos);
		return dibujo;
	}

	@Override
	public boolean playerWins() {
		return this.numLemmingsToWin()<=this.numLemmingsExit()&&this.numLemmingsInBoard()==0;
	}

	@Override
	public boolean playerLooses() {
		return this.numLemmingsExit()+this.numLemmingsInBoard()<this.numLemmingsToWin()&&this.numLemmingsInBoard()==0;
	}

// GameModel methods
	 @Override
	public void update() {
		this.container.update();
		this.incCicle();
	}
	// @Override
	public void exit() {
		this.exit=true;	
	}
	//@Override
	public boolean isFinished() {
		return this.playerLooses()||this.playerWins()||this.exit;
	}
	public void initGame1() {
		GameWorld prueba =  this;
		this.initGame0();
		this.container.add(new Lemming(prueba,new Position(3,3),new WalkerRole()));
		this.numLemmings++;
		
	}
	public void initGame0() {
		this.lemmings_win = 2;
		this.cycle=0;
		this.numLemmings=0;
		this.container= new GameObjectContainer();
		this.cycle=0;
		this.lemmingsSalida =0;
		this.lemmingsMuertos=0 ;	
		GameWorld prueba =  this;
			
		this.container.add(new Lemming(prueba,new Position(9,0),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new Lemming(prueba,new Position(2,3),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new ExitDoor(this, new Position(4,5)));
		this.container.add(new Lemming(prueba,new Position(0,8),new WalkerRole()));
		this.numLemmings++;
	
		this.container.add(new Pared(this,new Position(9,1)));
		this.container.add(new Pared(this, new Position(8,1)));
		this.container.add(new Pared(this, new Position(9,9)));
		this.container.add(new Pared(this, new Position(8,9)));
		this.container.add(new Pared(this, new Position(8,8)));
		this.container.add(new Pared(this, new Position(0,9)));
		this.container.add(new Pared(this, new Position(1,9)));
		this.container.add(new Pared(this, new Position(7,6)));
		this.container.add(new Pared(this, new Position(6,6)));
		this.container.add(new Pared(this, new Position(5,6)));
		this.container.add(new Pared(this, new Position(4,6)));
		this.container.add(new Pared(this, new Position(7,5)));
		this.container.add(new Pared(this, new Position(2,4)));
		this.container.add(new Pared(this, new Position(3,4)));
		this.container.add(new Pared(this, new Position(4,4)));
	
	}
	public void initGame2() {
		this.initGame1();
		GameWorld prueba =  this;
		this.container.add(new Lemming(prueba,new Position(6,0),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new Lemming(prueba,new Position(6,0),new ParachuterRole()));
		this.numLemmings++;
		this.container.add(new Pared(this, new Position(3,5)));
		this.container.add(new MetalWall(this, new Position(3,6)));	
	}
	public void initGame(int nLevel) {
		if(nLevel==1) {
			initGame1();
		}
		else if(nLevel==2) {
			initGame2();
		}
		else {
			initGame0();
		}
	}
	public int getLevel() {
		return this.level;
	}
	public void incCicle() {
		this.cycle++;
	}
	

	
// GameWorld methods (callbacks)
	 @Override
	public boolean isInAir(Position pos) {
			return !this.container.isSolid(pos);
    }
		
	 @Override
	public void lemmingArrived() {
		 lemmingsSalida++ ;
		 this.numLemmings--;
	}
	 public void lemmingMuerto() {
		 lemmingsMuertos++ ;
		 this.numLemmings--;
	}
	 @Override
	public boolean posSolido(Position pos) {
		return this.container.isSolid(pos);
	}
	 
	 @Override
	public boolean posExit(Position pos) {
	return this.container.isSalida(pos);		
	}
	 @Override
	public boolean roleCambiar(Position pos,LemmingRole rol) {
		 return this.container.cambiarRole(pos,rol);
	 }
	 public boolean receiveInteractionsFrom(GameItem obj) {
		 return this.container.receiveInteractionsFrom(obj);
	 }



}

