package tp1.control.commands;

import java.util.Arrays;
import java.util.List;

import tp1.exceptions.CommandParseException;
import tp1.view.Messages;

public class CommandGenerator {

	private static final List<Command> availableCommands = Arrays.asList(
		new SetRoleCommand(),
		new UpdateCommand(),
		new ResetCommand(),
		new LoadCommand(),
		new SaveCommand(),
		new HelpCommand(),
		new ExitCommand()
		
	);

	public static Command parse(String[] commandWords) throws CommandParseException {
		Command com;
		for (Command c: availableCommands) {
			com=c.parse(commandWords);
			if(com!=null) {
				return com;
			}
		}
		throw new CommandParseException(Messages.UNKNOWN_COMMAND.formatted(commandWords[0]));
	}
		
	public static String commandHelp() {
		StringBuilder commands = new StringBuilder();
		for (Command c: availableCommands) {
			commands.append(c.helpText());
		}
		return commands.toString();
	}
	@Override
	public String toString() {
		return "Command Generator";
	}
}
