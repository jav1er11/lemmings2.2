package tp1.control.commands;

import tp1.exceptions.CommandExecuteException;
import tp1.exceptions.CommandParseException;
import tp1.exceptions.GameLoadException;
import tp1.logic.GameModel;
import tp1.view.GameView;
import tp1.view.Messages;

public class LoadCommand extends Command {
	private static final String NAME = Messages.COMMAND_LOAD_NAME;
	private static final String SHORTCUT = Messages.COMMAND_LOAD_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_LOAD_DETAILS;
	private static final String HELP = Messages.COMMAND_LOAD_HELP;
	private String filename;
	
	LoadCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}

	public LoadCommand(String string) {
		super(NAME, SHORTCUT, DETAILS, HELP);
		this.filename= string;
	}

	@Override
	public void execute(GameModel game, GameView view) throws CommandExecuteException {
		try {
			game.load(this.filename);
			view.showGame();
		} catch (GameLoadException e) {
			StringBuilder icono = new StringBuilder();	
			icono.append('"');
			icono.append(filename);
			icono.append('"');
			throw new CommandExecuteException("Invalid file "+icono + " configuration",e);
		}
	}

	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		if(!this.matchCommandName(commandWords[0])||commandWords.length<1){
			return null;
		}
		else if(commandWords.length==2) {
			return new LoadCommand(commandWords[1]);
		}
		throw new CommandParseException(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);	
	}

}
