package tp1.control.commands;

import java.util.Arrays;
import java.util.List;

import tp1.exceptions.CommandExecuteException;
import tp1.exceptions.CommandParseException;
import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.ConsoleView;
import tp1.view.GameView;
import tp1.view.Messages;

public class ResetCommand extends Command {

    private static final String NAME = Messages.COMMAND_RESET_NAME;
    private static final String SHORTCUT = Messages.COMMAND_RESET_SHORTCUT;
    private static final String DETAILS = Messages.COMMAND_RESET_DETAILS;
    private static final String HELP = Messages.COMMAND_RESET_HELP;
    private static final String ERROR = "Not valid level number";

    
    private String nlvl;
    private boolean sinparam;
    
   
    public ResetCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		sinparam=true;

	}
    public ResetCommand(String nLevel) {
  		super(NAME, SHORTCUT, DETAILS, HELP);
    	this.nlvl=nLevel;
		sinparam=false;

  	}
	
	@Override
	public void execute(GameModel game, GameView view) throws CommandExecuteException {
		if(sinparam) {
			game.initGame();
			view.showGame();
		}
		else {
			if(game.comprobarNivel(nlvl)) {
				game.initGame(Integer.parseInt(this.nlvl));
				view.showGame();
			}
			else {
				throw new CommandExecuteException(this.ERROR);
			}
		}		
	}

	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		if(!this.matchCommandName(commandWords[0])||commandWords.length<1){
			return null;
		}
		else if(commandWords.length==1) {
			return new ResetCommand();
		}
		else if(commandWords.length==2) {
			return new ResetCommand(commandWords[1]);
		}
	 	throw new CommandParseException(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);

	}
	
	
	
}

