
package tp1.logic;

import tp1.exceptions.GameLoadException;
import tp1.exceptions.OffBoardException;
import tp1.exceptions.SaveException;
import tp1.logic.lemmingRoles.LemmingRole;

public interface GameModel {
	public void initGame1();
	public void initGame0();
	public void initGame(int nLevel);
	public void update();
	public boolean comprobarNivel(String lvl);
	public void exit();
	public boolean isFinished();
	public void initGame();
	boolean roleCambiar(Position pos, LemmingRole rol) throws OffBoardException;
	public void load(String fileName) throws GameLoadException;
	public void save(String filename) throws SaveException;
}
