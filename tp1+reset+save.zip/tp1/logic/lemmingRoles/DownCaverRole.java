package tp1.logic.lemmingRoles;

import tp1.logic.Direction;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Pared;
import tp1.view.Messages;

public class DownCaverRole extends AbstractRole {
	private static final String name = Messages.DOWNCAVER_ROL_NAME;
	private static final String help = Messages.DOWNCAVER_ROL_HELP;
	private static final String symbol = Messages.DOWNCAVER_ROL_SYMBOL;
	public DownCaverRole() {
		super(name, symbol, help);
	}
	
	@Override
	public void play(Lemming lemming) {
		lemming.walkOrFall();	
	}

	@Override
	public String getIcon(Lemming lemming) {
		return Messages.LEMMING_DOWN_CAVER;
	}

	@Override
	public void incFuerzaCaida(Lemming lemming) {
		lemming.incFuerza();
	}
	@Override
	public boolean interactWith(Pared wall,Lemming lemming) {
		boolean interact=lemming.paredEstaEnDir(wall, Direction.NONE);
		if(interact) {
			wall.muere();
		}
		return interact;
	}
	@Override
	public void setWalkerRole(Lemming lemming) {
		if(lemming.isInAir()||!lemming.receiveInteractionsFrom()) {
			lemming.setWalker();
			lemming.setFuerza0();
		}	
	}
}
