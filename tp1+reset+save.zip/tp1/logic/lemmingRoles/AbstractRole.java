package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Pared;

public abstract class AbstractRole implements LemmingRole {
	private final String name;
	private final String symbol;
	private final String help;
	
	public AbstractRole(String name, String symbol,  String help) {
		this.name = name;
		this.symbol =symbol;
		this.help = help;
	}
	public String getName() { return name; }
	 
	protected String getSymbol() { return symbol; }
	
	protected String getHelp() { return help; }
	 
	public abstract void play( Lemming lemming );
	public abstract String getIcon( Lemming lemming );
	 
	protected boolean matchRoleName(String name) {
		return getSymbol().equalsIgnoreCase(name) || 
		getName().equalsIgnoreCase(name);
	}
	 
	public AbstractRole parse(String input) {
		AbstractRole com=null;
		if(this.matchRoleName(input)) {
			com=this;
		}
		return com;
	} 
	public abstract void incFuerzaCaida(Lemming lemming);
	 public  boolean noSobrevive(Lemming lemming) {
		return lemming.noVive();
	 }
	public boolean equals(LemmingRole role) {
			return this==role||
			this instanceof LemmingRole&& this.getName().equals(role.getName());
	}
	public boolean interactWith(Pared wall,Lemming lemming) {
			return false;
	}
	public void setWalkerRole(Lemming lemming) {
			 
	}
	@Override
	public  String toString() {
		return this.name;
	}

}
