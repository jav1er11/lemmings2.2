package tp1.logic;

import tp1.exceptions.ObjectParseException;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.view.ConsoleView;
import tp1.view.Messages;

/**
 * 
 * Immutable class to encapsulate and manipulate positions in the game board
 * 
 */
public class Position {

	private final int col;
	private final int row;

	public Position (int x,int y) {
		this.col=x;
		this.row=y;
	}
	
	public Position (Position pos, Direction dir) {
		this.col=pos.col+dir.getX();
		this.row=pos.row+dir.getY();
	}
	
	
	 public boolean equals(Position pos) {
		return this==pos||
		this instanceof Position&&this.col==pos.col&& this.row==pos.row ;
	 };
	
	public boolean seSaleder() {
		return this.col>= Game.DIM_X;
	}
	
	public boolean seSaleiz() {
		return this.col< 0;
	}
	
	public boolean seSaleArriba() {	
		return this.row<0;
	}
	public boolean fueraTablero() {	
		return this.seSale()||this.seSaleAb()||this.seSaleArriba();
	}
	
	public String toString() {
		return "("+this.row+","+this.col+")";
	}
	public boolean seSale()
	{
		return this.seSaleiz()||this.seSaleder();
	}
	public boolean estaEnDir(Direction dir, Position pos) {
	Position posicion = new Position(this,dir);
		return pos.equals(posicion);
	}
	public boolean seSaleAb() {
		return this.row>=Game.DIM_Y;
	}
	public String toStringLetras() {
		return "("+ConsoleView.getRowName(row)+","+ConsoleView.getColName(this.col)+")";

	}
}
