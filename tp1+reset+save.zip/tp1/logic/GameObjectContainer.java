package tp1.logic;

import java.util.ArrayList;
import java.util.List;

import tp1.exceptions.ObjectParseException;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.gameobjects.GameObjectFactory;
import tp1.logic.lemmingRoles.LemmingRole;

public class GameObjectContainer {
	private List<GameObject> objects;

	public GameObjectContainer() {
		objects = new ArrayList<GameObject>();
	}
	
	// Only one add method (polymorphism)
	public void add(GameObject object) {
		this.objects.add(object);
	}
	public String iconoPos(Position pos){
		StringBuilder icon = new StringBuilder();	
		for(GameObject object: objects) {
			if(object.isInPosition(pos)) {
				icon.append(object.getIcon());
			}
		}
		return icon.toString();
	}
	public boolean isSolid(Position pos) {
		for(GameObject object: objects) {
			if(object.isSolid()&&object.isInPosition(pos)) {
				return true;
			}
		}
		return false;
	}
	public boolean isSalida(Position pos) {
		for(GameObject object: objects) {
			if(object.isExit()&&object.isInPosition(pos)) {
				return true;
			}
		}
		return false;
	}

	public void update() {
		int i=0;
		while(i<this.objects.size()) {
			if(this.objects.get(i).haAcabado()) {
				this.objects.remove(i);			
			}
			else {
				i++;
			}			
		}
		
		for (GameObject object: objects) {
				object.update();				
		}
		i=0;
		while(i<this.objects.size()) {
			if(!this.objects.get(i).isAlive()) {
				this.objects.remove(i);		
			}
			else {
				i++;
			}			
		}
	}

	public boolean cambiarRole(Position pos,LemmingRole rol) {
		for(GameObject object: objects) {
				if(object.setRole(rol,pos)) {
					return true;
				}			
			}
		return false;
		}
	public boolean receiveInteractionsFrom(GameItem obj) {
		 boolean found=false;
		 for(GameObject object: objects) {
			 if(object.receiveInteraction(obj)) {
				 found= true;			
			 }			
		 }
		  return found;
	  }
	  @Override
	public String toString() {
		return "GameObjectContainer";
	}  
	public void copy(GameObjectContainer cont) {
		for(GameObject object: cont.objects) {
			GameObject ob;
			try {
				ob = GameObjectFactory.parse(object.toString());
				this.add(ob);
			} 
			catch (ObjectParseException e) {
				e.printStackTrace();
			}
		}
	}
	public List<String> objetosToString() {
		List<String>objetos;
		objetos=  new ArrayList<String>();
		for(GameObject object:this.objects) {
			objetos.add(object.toString());
		}
		return objetos;
	}
}
	

	




