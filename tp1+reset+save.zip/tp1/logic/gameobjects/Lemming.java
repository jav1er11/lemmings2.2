package tp1.logic.gameobjects;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.exceptions.RoleParseException;
import tp1.logic.Direction;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.logic.lemmingRoles.WalkerRole;

public class Lemming extends GameObject {
	private Direction direccion; 
	private static final int MAXCAIDA=2;
	private int fuerzaCaida;
	private boolean llego;
	private LemmingRole role;
	
	
	
	public Lemming(GameWorld game, Position pos, LemmingRole rol) {
		super(game, pos);
		this.role = rol;
		this.direccion= Direction.RIGHT;  
		llego=false;
		this.fuerzaCaida=0;
		this.nombre="Lemming";
	}
	public Lemming(GameWorld game, Position pos, LemmingRole rol,Direction dir,int fuerzaCaida) {
		super(game, pos);
		this.role = rol;
		this.direccion= dir;  
		llego=false;
		this.fuerzaCaida=fuerzaCaida;
		this.nombre="Lemming";
	}
	protected Lemming()
	{
		super("Lemming");	
	}	
	public void walkOrFall() {
		if(!this.haAcabado()) {	
			this.pos= new Position(this.pos,Direction.DOWN);
			if(!this.game.isInAir(this.pos)&&!this.game.receiveInteractionsFrom(this)) {		
				this.role.setWalkerRole(this);
				this.mover();
				if(this.game.posExit(this.pos)) {
					this.llego=true;
				}
			}
			else if(this.pos.seSaleAb()) {
				this.muere();
			}
		else 	{
			this.role.setWalkerRole(this);
			this.role.incFuerzaCaida(this);	
		}
		}
		if(this.game.posExit(pos)) {
			this.llego=true;	
		}	
	}
	
	public void update() {
		if (isAlive()) 	
		role.play(this);
	}
	@Override
	public String getIcon() {
		return this.role.getIcon(this);
	}
	@Override
	public void muere() {
		this.isAlive=false;
	}
	
	public void incNumMuertos() {
		this.game.lemmingMuerto();
	}
	
	 @Override
	 public String toString(){
		 return this.pos.toString()+ " Lemming "+this.direccion.toString()+" "+this.fuerzaCaida+
					" "+this.role.toString();
	 }
	 public boolean isSolid() {
		 return false;
	 }
	 public Direction getDir() {
		 return this.direccion;
	 }
	 public boolean noVive() {
		 return (this.fuerzaCaida>this.MAXCAIDA)&&!this.isInAir();
	 }
	 public void incNumSalida(){
		 this.game.lemmingArrived();
	}
	 
	 @Override
	 public boolean haAcabado() {
		if(this.llego) {
			this.incNumSalida();
		}
		return this.llego;
	 }
	 
	 public void incFuerza() {
		 this.fuerzaCaida++;
	 }
	 public void setFuerza0() {
		 this.fuerzaCaida=0;
	 }
	 @Override
	 public boolean setRole(LemmingRole role, Position pos) {
		 	boolean ret= !this.role.equals(role)&&this.pos.equals(pos);
			if( !this.role.equals(role)&&this.pos.equals(pos)) {
				this.role=role;
			}
			return ret ;
		}
	 @Override
		public boolean receiveInteraction(GameItem other) {
			return other.interactWith(this);
	}
	 @Override
	 public boolean isAlive() {
		 if(!isAlive) {
		 	this.incNumMuertos();
		 }
		 return isAlive;
	}
	 @Override
	 public boolean interactWith(ExitDoor door) {	
	
		return this.pos.equals(door.pos);					
	 }
	 @Override
	 public boolean interactWith(Pared wall) {
		 return role.interactWith(wall, this);
		}
	 public void setWalker() {
		 this.role= new WalkerRole();
	 }
	 public void roleSetWalker() {
		 
	 }
	 
	 public boolean isInAir() {
		 return this.game.isInAir(pos);
	 }
	 
	 public boolean isInAirAbajo() {
		 return this.game.isInAir(new Position(this.pos,Direction.DOWN));
	 }
	 public boolean paredEstaEnDir(Pared wall,Direction dir) {
		return this.pos.estaEnDir(dir,wall.pos ); 
	 }
	 private void mover(){
		if(!this.role.noSobrevive(this)) {					
			this.fuerzaCaida=0;
			this.pos= new Position(this.pos,Direction.UP);
			this.pos= new Position(this.pos,this.direccion);
			if(this.pos.seSale()) {
				this.direccion= this.direccion.opuestoDir(this.direccion);	
				this.pos= new Position(this.pos,this.direccion);	

			}
		else { //no seSale
			if(!this.game.isInAir(this.pos)) {
				this.direccion= this.direccion.opuestoDir(this.direccion);
				this.pos= new Position(this.pos,this.direccion);	
			}
		}	
		}
	 }
	 public boolean receiveInteractionsFrom() {
		 return this.game.receiveInteractionsFrom(this);
	 }
	 @Override
     public GameObject parse(String line, GameWorld game) throws ObjectParseException, OffBoardException{
    	 String objeto [] = line.trim().split("\s+");
    	 Lemming lem;
    	 try {
    	 if(objeto.length==5&& this.matchObjectName(objeto[1])) {
    		 Position pos = this.getPosDeString(objeto[0]);
    		 if(pos.fueraTablero()) {
    			 throw new OffBoardException("Object position is off board: ");
    		 }
    		 else {
    	    	 LemmingRole rol= LemmingRoleFactory.parse(objeto[4]);
    	    	 int caida= Integer.parseInt(objeto[3]);
    	    	 Direction dir=this.getDirFromLine(objeto[2]);
    	    	 lem= new Lemming(game,pos,rol,dir,caida);
    		 }	 
    	 }
    	 else {
    		 lem=null;
    	 }
    	 }
    	 catch(NumberFormatException e) {
    		 throw new ObjectParseException("argumentos incorrectos",e);
    	 }
    	 catch(RoleParseException e) {
    		 throw new ObjectParseException("Invalid lemming role: "+this.ponerComillasString(line));
    	 }
    	 catch(ObjectParseException e) {
    		 throw new ObjectParseException(e.getMessage()+this.ponerComillasString(line));
    	 }
    	 return lem;
     }
	 public Direction getDirFromLine(String dire) throws ObjectParseException{
			Direction dir;
			if(dire.equalsIgnoreCase(Direction.RIGHT.toString())) {
				dir= Direction.RIGHT;
			}
			else if(dire.equalsIgnoreCase(Direction.LEFT.toString())) {
				dir= Direction.LEFT;
			}
			else if(dire.equalsIgnoreCase(Direction.DOWN.toString())||dire.equalsIgnoreCase(Direction.UP.toString())) {
				throw new ObjectParseException("Invalid lemming direction: ");
			}
			else if(dire.equalsIgnoreCase(Direction.NONE.toString())) {
				dir= Direction.NONE;
			}
			else {
				throw new ObjectParseException("Unknown object direction: ");
			}
			return dir;
		}
	 public String ponerComillasString(String linea) {
			StringBuilder icono = new StringBuilder();	
			icono.append('"');
			icono.append(linea);
			icono.append('"');
			return icono.toString();
		}
 }

