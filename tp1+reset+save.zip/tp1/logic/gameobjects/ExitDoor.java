package tp1.logic.gameobjects;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.view.Messages;

public class ExitDoor extends GameObject {
	
	public ExitDoor (GameWorld game, Position pos) {
		super(game, pos);
	}
	protected ExitDoor()
	{
		super("ExitDoor");
	}
	public boolean doorIsInPos(Position pos) {
		return this.pos.equals(pos);	
	}
	public String getIcon() {
		return Messages.EXIT_DOOR;
	}
	public String toString() {
		return this.pos.toString()+" ExitDoor";
	}
	public boolean isSolid() {
		return false;
	}
	@Override
	public boolean isExit() {
		return true;
	 }
	 @Override
	public void update() {
	    	 
	}
	 @Override
	public boolean receiveInteraction(GameItem other) {
		return other.interactWith(this);
	}
	 @Override
	public boolean interactWith(Lemming lemming) {
		return false;
	}
	@Override
	public GameObject parse(String line, GameWorld game) throws ObjectParseException, OffBoardException{
	    String objeto [] = line.trim().split("\s+"); 
	    ExitDoor puerta=null;
	    if(objeto.length==2&& this.matchObjectName(objeto[1])) {
	    	Position pos = this.getPosDeString(objeto[0]);
	    	if(pos.fueraTablero()) {
	    		throw new OffBoardException("Object position is offboard ");
	    	}
	    	else {
	    		puerta= new ExitDoor(game,pos); 
	    	}	 
	     }
	    return puerta;	 
	}
}
