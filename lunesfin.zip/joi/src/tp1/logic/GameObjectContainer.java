package tp1.logic;

import java.util.ArrayList;
import java.util.List;

import tp1.logic.gameobjects.GameObject;

public class GameObjectContainer {
	private List<GameObject> objects;

	public GameObjectContainer() {
		objects = new ArrayList<GameObject>();
	}
	
	// Only one add method (polymorphism)
	public void add(GameObject object) {
	 this.objects.add(object);
	}
	public String iconoPos(Position pos){
		String icon="";
			
		for(GameObject object: objects) {
			if(object.isInPosition(pos)) {
				icon+= object.getIcon();
			}
		}
		return icon;
	}
	public boolean isSolid(Position pos) {
	boolean found=false;
	for(GameObject object: objects) {
		found=object.isSolid()&&object.isInPosition(pos);	
		if(found) {
			return true;
		}
	}
	return false;
	}
	public boolean isSalida(Position pos) {
		boolean found=false;
		for(GameObject object: objects) {
			found=object.isExit()&&object.isInPosition(pos);	
			if(found) {
				return true;
			}
		}
	return found;
	}

	public void update() {
		for(int i=0;i<this.objects.size();i++) {
			if(!this.objects.get(i).isAlive()) {
				this.objects.get(i).incNumMuertos();
				this.objects.remove(i);		
			}
			else if(this.objects.get(i).haAcabado()) {
				this.objects.get(i).incNumSalida();
				this.objects.remove(i);
				
			}
		}
		for (GameObject object: objects) {
			if(object.isAlive()&&!object.haAcabado()) {
				object.update();
				}
			else if(object.haAcabado()) {
				
			}
			else {
								
			}
		}
		
	}	
}
	




