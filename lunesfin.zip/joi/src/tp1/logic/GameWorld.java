package tp1.logic;

public interface GameWorld {
	
	
	public void lemmingArrived();
	public boolean posSolido(Position pos);
	public boolean roleCambiar(Position pos);
	public boolean posExit(Position pos);
	public boolean isInAir(Position pos);
	public void lemmingMuerto();
	
}