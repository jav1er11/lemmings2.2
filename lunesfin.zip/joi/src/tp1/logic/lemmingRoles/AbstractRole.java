package tp1.logic.lemmingRoles;

import tp1.control.commands.Command;
import tp1.logic.gameobjects.Lemming;

public abstract class AbstractRole implements LemmingRole {
	 private final String name;
	 private final String symbol;
	 private final String help;
	
	 public AbstractRole(String name, String symbol,  String help) {
			this.name = name;
			this.symbol =symbol;
			this.help = help;
		}
	 protected String getName() { return name; }
		protected String getSymbol() { return symbol; }
		
		protected String getHelp() { return help; }
	 
	 public abstract void start( Lemming lemming );
	 public abstract void play( Lemming lemming );
	 public abstract String getIcon( Lemming lemming );
	 
	 protected boolean matchRoleName(String name) {
			return getSymbol().equalsIgnoreCase(name) || 
					getName().equalsIgnoreCase(name);
	}
	public AbstractRole parse(String input) {
		AbstractRole com=null;
		if(this.matchRoleName(input)) {
			com=this;
		}
		return com;
		
	} 
	

}
