
package tp1.logic;

public interface GameModel {
public void initGame1();
public void initGame0();
public void initGame(int nLevel);
public void update();
public int getLevel();
public void exit();
}
