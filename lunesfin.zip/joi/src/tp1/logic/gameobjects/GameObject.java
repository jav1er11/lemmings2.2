package tp1.logic.gameobjects;
import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;

public abstract class GameObject {

	protected Position pos;
	protected boolean isAlive;
	protected GameWorld game;
	
	public GameObject(GameWorld game, Position pos) {
		this.isAlive = true;
		this.pos = pos;
		this.game = game;
	}
	
	public boolean isInPosition(Position p) {
		return this.pos.equals(p);
	}
 	
	public boolean isAlive() {
		return isAlive;
	}
	public void muere() {
		this.isAlive=false;
	}
	public void incNumMuertos()
	{
		
	}
	public void incNumSalida()
	{
		
	}
	public boolean setRole(LemmingRole role) {
		return false;
	}
	public abstract boolean isSolid();
	 
	 public boolean isExit() {
		return false;
	 }
	 public boolean haAcabado() {
			return false;
		 }
	 public abstract void update();
	
	public abstract String getIcon();

}

