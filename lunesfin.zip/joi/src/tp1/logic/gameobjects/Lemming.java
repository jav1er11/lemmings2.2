package tp1.logic.gameobjects;

import tp1.logic.Direction;
import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.ParachuterRole;
import tp1.logic.lemmingRoles.WalkerRole;

public class Lemming extends GameObject {


    private Direction direccion; 
	private Position posicion;
	private final boolean solido=false;
	private final int maxCaida=2;
	private int fuerzaCaida;	
	ParachuterRole role;
	
	public Lemming(GameWorld game, Position pos) {
		super(game, pos);
		this.role = new ParachuterRole();
		this.direccion= Direction.RIGHT;                      	
		this.fuerzaCaida=0;
	}
	
	private WalkerRole WalkerRole() {
		// TODO Auto-generated method stub
		return null;
	}

	// Not mandatory but recommended
	public void walkOrFall() {
		
			this.pos= new Position(this.pos,Direction.DOWN);
			if(!this.game.isInAir(this.pos)) {
				if(!this.role.noSobrevive(this)) {
					this.fuerzaCaida=0;
					this.pos= new Position(this.pos,Direction.UP);
					this.pos= new Position(this.pos,this.direccion);
						if(this.pos.seSale()) {
							this.direccion= this.direccion.setnewDir(this.direccion);	
							this.pos= new Position(this.pos,this.direccion);
						}
						else { //no seSale
							if(!this.game.isInAir(this.pos)) {
								this.direccion= this.direccion.setnewDir(this.direccion);
								this.pos= new Position(this.pos,this.direccion);	
							}
						}	
						
				}
				if(this.game.posExit(this.pos)) {
					this.direccion= this.direccion.setDir(4);
				}
			}
			else if(this.pos.seSaleAb()) {
				this.muere();
			}				
			else {
				this.role.incFuerzaCaida(this);
			}
	}

	public void update() {
		if (isAlive()) 	
		role.play(this);
	}
	@Override
	public String getIcon() {
		return this.role.getIcon(this);
	}
	@Override
	public void muere() {
		this.isAlive=false;
	}
	@Override
	public void incNumMuertos() {
		this.game.lemmingMuerto();
	}
	
	 @Override
	 public String toString(){
		 return this.posicion.toString()+ " L "+this.direccion.toString()+" "+this.fuerzaCaida+
					" "+this.role.toString();
	 }
	 public boolean isSolid() {
		 return false;
	 }
	 public Direction getDir() {
		 return this.direccion;
	 }
	 public boolean noVive() {
		 return this.fuerzaCaida>this.maxCaida;
	 }
	 @Override
	 public void incNumSalida()
		{
		 this.game.lemmingArrived();
		}
	 @Override
	 public boolean haAcabado() {
		return this.direccion.equals(Direction.NONE);
	 }
	 public void incFuerza() {
		 this.fuerzaCaida++;
	 }
	 public void setFuerza0() {
		 this.fuerzaCaida=0;
	 }
	 @Override
	 public boolean setRole(LemmingRole role) {
			boolean si;
			if(this.role.equals(role)) {
				si=false;
			}
			else {
				si=true;
			}
			return si;
		}
}

