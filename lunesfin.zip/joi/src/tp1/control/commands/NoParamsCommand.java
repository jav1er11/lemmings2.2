package tp1.control.commands;

import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.view.GameView;

public abstract class NoParamsCommand extends Command {

	public NoParamsCommand(String name, String shortcut, String details, String help) {
		super(name, shortcut, details, help);
	}

	@Override
	public Command parse(String[] commandWords) {
		Command com=null;
		if(this.matchCommandName(commandWords[0])&&commandWords.length==1) {
			com=this;
		}
		return com;
	}
	public abstract void execute(GameModel game, GameView view);
}
