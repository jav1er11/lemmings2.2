package tp1.control.commands;

import tp1.logic.GameModel;
import tp1.view.GameView;
import tp1.view.Messages;

public class SetRoleCommand extends Command {

    private static final String NAME = Messages.COMMAND_SETROLE_NAME;
    private static final String SHORTCUT = Messages.COMMAND_SETROLE_SHORTCUT;
    private static final String DETAILS = Messages.COMMAND_SETROLE_DETAILS;
    private static final String HELP = Messages.COMMAND_SETROLE_HELP;

	public SetRoleCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}
	@Override
	public Command parse(String[] commandWords) {
		Command com=null;
		if(this.matchCommandName(commandWords[0])&&commandWords.length==1) {
			com=this;
		}
		return com;
	}
	@Override
	public void execute(GameModel game, GameView view) {
		System.out.println("Hola");
		
	}

}
