package tp1.logic.gameobjects;

import java.util.Arrays;
import java.util.List;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.logic.GameWorld;
import tp1.logic.lemmingRoles.AbstractRole;
import tp1.logic.lemmingRoles.DownCaverRole;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.ParachuterRole;
import tp1.logic.lemmingRoles.WalkerRole;

public class GameObjectFactory {
	private static GameWorld game;
	public GameObjectFactory(GameWorld game){
		this.game=game;
	}
	private static final List<GameObject> availableObjects = Arrays.asList(
			new Lemming(),
			new ExitDoor(),
			new MetalWall(),
			new Pared()		
	);
	public static GameObject parse(String input) throws ObjectParseException{
		try {
			GameObject obj;
			for (GameObject c: availableObjects) {
				obj=c.parse(input, game);
				if(obj!=null) {
					return obj;
				}
			} 
			StringBuilder icono = new StringBuilder();	
			icono.append('"');
			icono.append(input);
			icono.append('"');
			throw new ObjectParseException("Unknown game object: "+icono);
			}	
		catch ( OffBoardException e) {
			StringBuilder icono = new StringBuilder();	
			icono.append('"');
			icono.append(input);
			icono.append('"');
			throw new ObjectParseException(e.getMessage()+icono);
		} 
	}
}
