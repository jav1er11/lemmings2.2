package tp1.control;

import tp1.control.commands.Command;
import tp1.control.commands.CommandGenerator;
import tp1.exceptions.CommandException;
import tp1.exceptions.CommandParseException;
import tp1.exceptions.ObjectParseException;
import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.view.GameView;
import tp1.view.Messages;

/**
 *  Accepts user input and coordinates the game execution logic
 */
public class Controller {

	private GameModel game;
	private GameView view;

	public Controller(GameModel game, GameView view) {
		this.game = game;
		this.view = view;
	}


	/**
	 * Runs the game logic, coordinate Model(game) and View(view)
	 */
	public void run(){
		
		String[] words = null;
		view.showWelcome();
		view.showGame();
		while ( !game.isFinished()) {
			words = view.getPrompt();
			Command command=null;
			try {
				command = CommandGenerator.parse(words);
				if (command != null)
					command.execute(game, view);
			} 
			catch (CommandException e) {
				if(e.getCause()!=null) {
					view.showError(e.getMessage()+"\n");
					if(e.getCause().getCause()!=null) {
						view.showError(e.getCause().getMessage());
						view.showError(e.getCause().getCause().getMessage()+"\n"+"\n");
					}
					else {
						view.showError(e.getCause().getMessage()+"\n"+"\n");
					}
				}
				else {
					view.showError(e.getMessage()+"\n"+"\n");
				}
			}
			
		}
		view.showEndMessage();
	}
}
