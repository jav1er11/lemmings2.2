package tp1.control.commands;

import tp1.exceptions.CommandExecuteException;
import tp1.exceptions.CommandParseException;
import tp1.exceptions.GameLoadException;
import tp1.logic.GameModel;
import tp1.logic.SaveException;
import tp1.view.GameView;
import tp1.view.Messages;

public class SaveCommand extends Command{
	private static final String NAME = Messages.COMMAND_SAVE_NAME;
	private static final String SHORTCUT = Messages.COMMAND_SAVE_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_SAVE_DETAILS;
	private static final String HELP = Messages.COMMAND_SAVE_HELP;
	private String filename;
	
	SaveCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}

	public SaveCommand(String string) {
		super(NAME, SHORTCUT, DETAILS, HELP);
		this.filename= string;
	}

	@Override
	public void execute(GameModel game, GameView view) throws CommandExecuteException {
		try {
			game.save(this.filename);
			view.showMessage("   File \"patata\" correctly saved\r\n"
					+ "");;
		} catch (SaveException e) {
			throw new CommandExecuteException(e);
		}
	}

	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		if(!this.matchCommandName(commandWords[0])||commandWords.length<1){
			return null;
		}
		else if(commandWords.length==2) {
			return new SaveCommand(commandWords[1]);
		}
		throw new CommandParseException(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);		
	}
	
}
