package tp1.control.commands;

import tp1.exceptions.CommandExecuteException;
import tp1.exceptions.CommandParseException;
import tp1.exceptions.GameModelException;
import tp1.exceptions.GameParseException;
import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.exceptions.RoleParseException;
import tp1.logic.GameModel;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.ConsoleView;
import tp1.view.GameView;
import tp1.view.Messages;

public class SetRoleCommand extends Command {

    private static final String NAME = Messages.COMMAND_SETROLE_NAME;
    private static final String SHORTCUT = Messages.COMMAND_SETROLE_SHORTCUT;
    private static final String DETAILS = Messages.COMMAND_SETROLE_DETAILS;
    private static final String HELP = Messages.COMMAND_SETROLE_HELP;
    private static final String ERROR = Messages.ERROR_COMMAND_SETROLE ;

    
    private LemmingRole role;
    private Position pos;
    
	SetRoleCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
	}
	public SetRoleCommand(LemmingRole role,Position pos) {
		super(NAME, SHORTCUT, DETAILS, HELP);
		this.pos=pos;
		this.role=role;
	}
	@Override
	public Command parse(String[] commandWords) throws CommandParseException {
		LemmingRole rol;
		Position posi;
		Command com=null;
		try {
			if(this.matchCommandName(commandWords[0])&&commandWords.length==4) {						
				rol= LemmingRoleFactory.parse(commandWords[1]);
				if(rol!=null) {				
					posi = new Position(ConsoleView.colNameToNum(commandWords[3]),
					Integer.parseInt(ConsoleView.rowNameToNum(commandWords[2])));	
					com= new SetRoleCommand(rol,posi);
				}
			}	  
			else if(this.matchCommandName(commandWords[0])&&commandWords.length!=4) {
				throw new CommandParseException(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);
			}	
		}
		catch (NumberFormatException e) {
		 	throw new CommandParseException(Messages.INVALID_POSITION.formatted
		 		(Messages.POSITION.formatted(commandWords[2],commandWords[3])),e);
		 }
		catch (RoleParseException e) {
		 	throw new CommandParseException("Unknown role: "+commandWords[1]);
		 }
		return com;	
	}
	@Override
	public void execute(GameModel game, GameView view) throws CommandExecuteException{
		
		try {
			if(game.roleCambiar(this.pos, this.role)) {
				game.update();
				view.showGame();
			}
			else {
				throw new ObjectParseException("No lemming in position "+pos.toString()
				+" admits role " +role.toString());
				
			}
		} catch (ObjectParseException e) {
			throw new CommandExecuteException(e.getMessage());		
		}
		catch (OffBoardException e) {
			throw new CommandExecuteException("Command execute problem",e);		
		} 
	
	}

}
