package tp1.logic;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import tp1.exceptions.GameLoadException;
import tp1.exceptions.ObjectParseException;
import tp1.logic.gameobjects.GameObjectFactory;

public class FileGameConfiguration implements GameConfiguration{
	public static final FileGameConfiguration NONE = new FileGameConfiguration();
	private int cicle;
	private int numLemmings;
	private int deadLemmings;
	private int lemmingsOut;
	private int numLemmingsToWin;
	private final GameObjectContainer gameObjCont;
	
	private FileGameConfiguration() {
		gameObjCont=null;
	}
	
	public FileGameConfiguration(String fileName, GameWorld game) throws GameLoadException {
		try {
			BufferedReader lector = new BufferedReader(new FileReader(fileName));
			String linea= lector.readLine();
			String lineArray[]= linea.trim().split("\s+"); 
			if(lineArray.length==5) {
				this.cicle= Integer.parseInt(lineArray[0]);
				this.numLemmings= Integer.parseInt(lineArray[1]);
				this.deadLemmings=Integer.parseInt(lineArray[2]);
				this.lemmingsOut= Integer.parseInt(lineArray[3]);
				this.numLemmingsToWin= Integer.parseInt(lineArray[4]);
				this.gameObjCont= new GameObjectContainer();//borrar add de game
				GameObjectFactory fact= new GameObjectFactory(game);
				linea= lector.readLine();
				while(linea!=null) {
					gameObjCont.add(fact.parse(linea));
					linea= lector.readLine();
				}
			}
			else {		
				throw new  GameLoadException("Invalid game status " + this.ponerComillasString(linea));
			}
		}
		catch(FileNotFoundException e){
			throw new  GameLoadException("File not found: "+this.ponerComillasString(fileName));
		}
		catch(IOException e){	
			throw new  GameLoadException(e);
		}
		catch(NumberFormatException e){	
			throw new  GameLoadException(e);
		}
		catch(ObjectParseException e){
			throw new  GameLoadException(e.getMessage());
		}
		
	}
	
	@Override
	public int getCycle() {
		return this.cicle;
	}
	@Override
	public int numLemmingsInBoard() {
		return this.numLemmings;
	}
	@Override
	public int numLemmingsDead() {
		return this.deadLemmings;
	}
	@Override
	public int numLemingsExit() {
		return this.lemmingsOut;
	}
	@Override
	public int numLemmingToWin() {
		return this.numLemmingsToWin;
	}
	@Override
	public GameObjectContainer getGameObjects() {
		return this.gameObjCont;
	}
	public String ponerComillasString(String linea) {
		StringBuilder icono = new StringBuilder();	
		icono.append('"');
		icono.append(linea);
		icono.append('"');
		return icono.toString();
	}

}
