package tp1.logic.lemmingRoles;

import java.util.Arrays;
import java.util.List;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.exceptions.RoleParseException;
import tp1.view.Messages;


public class LemmingRoleFactory {
	private static final List<AbstractRole> availableRoles = Arrays.asList(
			new WalkerRole(),
		    new ParachuterRole(),
		    new DownCaverRole()
	);
	public static LemmingRole parse(String input) throws RoleParseException{
		AbstractRole rol;
		for (AbstractRole c: availableRoles) {
			rol=c.parse(input);
			if(rol!=null) {
				return rol; //cambiar asi todas las factorias
			}
		}
		throw new RoleParseException("Unknown role: "+input);
	}	
}

