
package tp1.logic.gameobjects;

import tp1.exceptions.ObjectParseException;
import tp1.exceptions.OffBoardException;
import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;

public class Pared extends GameObject {

    public Pared (GameWorld game, Position pos) {
		super(game, pos);
	}
    public Pared (Pared wall) {
		super(wall);
	}
    protected Pared()
	{
		super("Wall");
	}
    	  
     public boolean paredIsInposition(Position pos) {
    	 return this.pos.equals(pos);
     }
     
     public String getIcon() {
    	 return Messages.WALL;
     }
     
     public String toString() {
    	 return this.pos.toString()+" "+"Wall";
     }	
     public boolean isSolid() {
    	 return true;
     }
     @Override
     public void update() {
    	 
     }
     @Override
		public boolean receiveInteraction(GameItem other) {
			return other.interactWith(this);
	}
     @Override
     public GameObject parse(String line, GameWorld game) throws ObjectParseException, OffBoardException{
    	 String objeto [] = line.trim().split("\s+"); 
    	 Pared par= null;
    	 if(objeto.length==2&& this.matchObjectName(objeto[1])) {
    		 Position pos = this.getPosDeString(objeto[0]);
    		 if(pos.fueraTablero()) {
    			 throw new OffBoardException("Object position is offboard ");
    		 }
    		 else {
    			par= new Pared(game,pos); 
    		 }	 
    	 }
    	 return par;	 
     }
    
}