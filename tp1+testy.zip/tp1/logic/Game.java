package tp1.logic;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import tp1.exceptions.GameLoadException;
import tp1.exceptions.OffBoardException;
import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.MetalWall;
import tp1.logic.gameobjects.Pared;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.ParachuterRole;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;

public class Game implements GameStatus, GameWorld, GameModel {
	private int numLemmings;
	private int cycle;
	private int level;
	private boolean exit;
	public static final int DIM_X = 10;
	public static final int DIM_Y = 10;
	private  int lemmingsSalida ;
	private  int lemmingsMuertos ;
	private int lemmings_win;
	private FileGameConfiguration conf;
	private GameObjectContainer container;
	 private static final List<String> AVAILABLELVLS= Arrays.asList(
				"0",
				"1",
				"2"		
		);
	    
	public Game(int nLevel) {
		this.container= new GameObjectContainer();
		this.initGame(nLevel);
		lemmingsSalida=0 ;
		this.exit=false;
	}
	
	@Override
	public int getCycle() {
		return this.cycle;
	}

	@Override
	public int numLemmingsInBoard() {
		return this.numLemmings;
	}

	@Override
	public int numLemmingsDead() {
		return this.lemmingsMuertos;
	}

	@Override
	public int numLemmingsExit() {
		return this.lemmingsSalida;
	}

	@Override
	public int numLemmingsToWin() {
		return lemmings_win;
	}

	@Override
	public String positionToString(int col, int row) {
		String dibujo;
		Position pos= new Position(col,row);
		dibujo= this.container.iconoPos(pos);
		return dibujo;
	}

	@Override
	public boolean playerWins() {
		return this.numLemmingsToWin()<=this.numLemmingsExit()&&this.numLemmingsInBoard()==0;
	}

	@Override
	public boolean playerLooses() {
		return this.numLemmingsExit()+this.numLemmingsInBoard()<this.numLemmingsToWin()&&this.numLemmingsInBoard()==0;
	}

	 @Override
	public void update() {
		this.container.update();
		this.incCicle();
	}
	// @Override
	public void exit() {
		this.exit=true;	
	}
	//@Override
	public boolean isFinished() {
		return this.playerLooses()||this.playerWins()||this.exit;
	}
	public void initGame1() {
		GameWorld prueba =  this;
		this.initGame0();
		this.container.add(new Lemming(prueba,new Position(3,3),new WalkerRole()));
		this.numLemmings++;
		
	}
	public void initGame0() {
		this.conf= FileGameConfiguration.NONE;
		this.lemmings_win = 2;
		this.numLemmings=0;
		this.container= new GameObjectContainer();
		this.cycle=0; 
		this.lemmingsSalida =0;
		this.lemmingsMuertos=0 ;	
		GameWorld prueba =  this;
			
		this.container.add(new Lemming(prueba,new Position(9,0),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new Lemming(prueba,new Position(2,3),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new ExitDoor(this, new Position(4,5)));
		this.container.add(new Lemming(prueba,new Position(0,8),new WalkerRole()));
		this.numLemmings++;
	
		this.container.add(new Pared(this,new Position(9,1)));
		this.container.add(new Pared(this, new Position(8,1)));
		this.container.add(new Pared(this, new Position(9,9)));
		this.container.add(new Pared(this, new Position(8,9)));
		this.container.add(new Pared(this, new Position(8,8)));
		this.container.add(new Pared(this, new Position(0,9)));
		this.container.add(new Pared(this, new Position(1,9)));
		this.container.add(new Pared(this, new Position(7,6)));
		this.container.add(new Pared(this, new Position(6,6)));
		this.container.add(new Pared(this, new Position(5,6)));
		this.container.add(new Pared(this, new Position(4,6)));
		this.container.add(new Pared(this, new Position(7,5)));
		this.container.add(new Pared(this, new Position(2,4)));
		this.container.add(new Pared(this, new Position(3,4)));
		this.container.add(new Pared(this, new Position(4,4)));
	
	}
	public void initGame2() {
		this.initGame1();
		GameWorld prueba =  this;
		this.container.add(new Lemming(prueba,new Position(6,0),new WalkerRole()));
		this.numLemmings++;
		this.container.add(new Lemming(prueba,new Position(6,0),new ParachuterRole()));
		this.numLemmings++;
		this.container.add(new Pared(this, new Position(3,5)));
		this.container.add(new MetalWall(this, new Position(3,6)));	
	}
	public void initGame(int nLevel) {
		this.level=nLevel;
		if(nLevel==1) {
			initGame1();
		}
		else if(nLevel==2) {
			initGame2();
		}
		else {
			initGame0();
		}
	}
	public void initGame() {
		if(this.conf==FileGameConfiguration.NONE){
			if(this.level==1) {
				initGame1();
			}
			else if(this.level==2) {
				initGame2();
			}
			else {
				initGame0();
			}
		}
		else {
			this.initLoad(conf);
		}
	}

	public void incCicle() {
		this.cycle++;
	}
	
	 @Override
	public boolean isInAir(Position pos) {
			return !this.container.isSolid(pos);
    }
		
	 @Override
	public void lemmingArrived() {
		 lemmingsSalida++ ;
		 this.numLemmings--;
	}
	 @Override
	 public void lemmingMuerto() {
		 this.lemmingsMuertos++ ;
		 this.numLemmings--;
	}
	 @Override
	public boolean posSolido(Position pos) {
		return this.container.isSolid(pos);
	}
	 
	 @Override
	public boolean posExit(Position pos) {
	return this.container.isSalida(pos);		
	}
	 @Override
	public boolean roleCambiar(Position pos,LemmingRole rol) throws OffBoardException{
		 if(pos.fueraTablero()) {
			 throw new OffBoardException("Position "+pos.toString()+" is off board");
		 }
		 else {
			 return this.container.cambiarRole(pos,rol); 
		 }	
	 }
	 
	 public boolean receiveInteractionsFrom(GameItem obj) {
		 return this.container.receiveInteractionsFrom(obj);
	 }
	 @Override
	 public boolean comprobarNivel(String lvl) {
			for (String c: AVAILABLELVLS) {
				if(c.equals(lvl)) {
					return true;
				}
			}
			return false;
		}

	 @Override
		public String toString() {
			return "Game"+" "+level;
		}
	 @Override
		public void addGameObject(GameObject obj) {
			this.container.add(obj);
		}
	 @Override
	public void load(String fileName) throws GameLoadException {
		 GameWorld prueba =  this;
		 this.conf = new FileGameConfiguration(fileName, prueba);
		 this.initLoad(conf);
	}
	 
	 public void initLoad(FileGameConfiguration conf) {
		 this.container= new GameObjectContainer();
		 this.container.copy(conf.getGameObjects()); 
		 this.cycle=conf.getCycle();
		 this.lemmings_win=conf.numLemmingToWin();
		 this.lemmingsMuertos= conf.numLemmingsDead();
		 this.lemmingsSalida=conf.numLemingsExit();
		 this.numLemmings=conf.numLemmingsInBoard(); 
	 }
	 public String statusToString() {
		 return Integer.toString(this.cycle)+" "+Integer.toString(this.numLemmings)+" "
				 +Integer.toString(this.lemmingsMuertos)+" "+Integer.toString(this.lemmingsSalida)+" "
				 +Integer.toString(this.lemmings_win); 
	 }
	@Override
	public void save(String filename) throws SaveException{
		try {
			FileWriter escritor= new FileWriter(filename);
			escritor.write(this.statusToString());
			escritor.write("\n");
			List<String>objetos;
			objetos=  new ArrayList<String>();
			objetos= this.container.objetosToString();
			for(String line: objetos) {
				escritor.write(line);
				escritor.write("\n");
			}
			escritor.close();
		}
		catch(IOException e) {
			throw new SaveException(e);
		}
		
		
	}	
}

