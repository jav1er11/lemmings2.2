package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;

public class ParachuterRole implements LemmingRole {
public ParachuterRole() {
		
	}
	public void start( Lemming lemming ) {
		
	}
    public void play( Lemming lemming ) {
		lemming.walkOrFall();	
    }
    public String getIcon( Lemming lemming ) {
    	return "🪂";
    }

    public void incFuerzaCaida(Lemming lemming) {
		lemming.setFuerza0();
	}
    public boolean noSobrevive(Lemming lemming) {
		return false;
	}
}
