package tp1.logic;

/**
 * 
 * Immutable class to encapsulate and manipulate positions in the game board
 * 
 */
public class Position {

	private int col;
	private int row;

	public Position (int x,int y) {
		this.col=x;
		this.row=y;
	}
	
	public Position (Position pos, Direction dir) {
		this.col=pos.col+dir.getX();
		this.row=pos.row+dir.getY();
	}
	
	public boolean equals(Position pos) {
		return this.col==pos.col&& this.row==pos.row;
	}
	
	public boolean seSaleder() {
		return this.col>= Game.DIM_X;
	}
	
	public boolean seSaleiz() {
		return this.col< 0;
	}
	
	public boolean seSaleAb() {
		return this.row>=Game.DIM_Y-1;
	}
	
	public String toString() {
		return "("+this.col+","+this.row+")";
	}
	public boolean seSale()
	{
		return this.seSaleiz()||this.seSaleder();
	}
}
