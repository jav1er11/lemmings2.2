package tp1.logic;

/**
 * Represents the allowed directions in the game
 *
 */
public enum Direction {
	LEFT(-1,0), RIGHT(1,0), DOWN(0,1), UP(0,-1), NONE(0,0);
	
	private int x;
	private int y;
	
	private Direction(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public Direction setnewDir(Direction dir) {
		if(dir==LEFT) {
			dir= RIGHT;
		}
		else if(dir==RIGHT) {
			dir= LEFT;
		}
		return dir;
	}
	public Direction setDir(int i) {
		Direction dir;
		if(i==0) {
			dir= LEFT;	
		}
		else if(i==1) {
			dir= RIGHT;		
		}
		else if(i==2) {
			dir= DOWN;	
		}
		else if(i==3){
			dir= UP;		
		}
		else {
			dir= NONE;
		}
		return dir;
	}
	
	
}

