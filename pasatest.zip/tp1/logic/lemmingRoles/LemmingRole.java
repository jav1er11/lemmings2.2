package tp1.logic.lemmingRoles;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Pared;

public interface LemmingRole {
	 public void play( Lemming lemming );
	 public String getIcon( Lemming lemming );
	 public boolean equals(LemmingRole role);
	 public void incFuerzaCaida(Lemming lemming);
	 public boolean noSobrevive(Lemming lemming);
	 public String getName();
	 public boolean interactWith(Pared wall,Lemming lemming);
	 public void setWalkerRole(Lemming lemming);
}
