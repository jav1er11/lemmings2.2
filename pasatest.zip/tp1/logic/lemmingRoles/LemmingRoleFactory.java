package tp1.logic.lemmingRoles;

import java.util.Arrays;
import java.util.List;


public class LemmingRoleFactory {
	private static final List<AbstractRole> availableRoles = Arrays.asList(
			new WalkerRole(),
		    new ParachuterRole(),
		    new DownCaverRole()
	);
	public static LemmingRole parse(String input) {
		AbstractRole rol=null;
		for (AbstractRole c: availableRoles) {
			if(rol==null) {
				rol=c.parse(input);
			}
		}
			return rol;
		
	}	
}
