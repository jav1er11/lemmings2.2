package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;
import tp1.view.Messages;

public class ParachuterRole extends AbstractRole {
	private static final String NAME = Messages.PARACHUTER_ROL_NAME;
	private static final String HELP = Messages.PARACHUTER_ROL_HELP;
	private static final String SYMBOL = Messages.PARACHUTER_ROL_SYMBOL;
	private static final String ICON_RIGHT = Messages.LEMMING_RIGHT;
	private static final String ICON_LEFT = Messages.LEMMING_LEFT;
	
	
	public ParachuterRole() {
	super(NAME,SYMBOL,HELP);
	}
 	
    public void play( Lemming lemming ) {
		lemming.walkOrFall();	
    }
    public String getIcon( Lemming lemming ) {
    	return "🪂";
    }

    public void incFuerzaCaida(Lemming lemming) {
		lemming.setFuerza0();
	}
    public boolean noSobrevive(Lemming lemming) {
		return false;
	}

	@Override
	public boolean equals(LemmingRole role) {
		return role.getName().equals(this.NAME);
	}
	@Override
	public void setWalkerRole(Lemming lemming) {
		if(!lemming.isInAir()) {
			lemming.setWalker();
		}
	}
    
}
