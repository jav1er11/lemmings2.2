package tp1.logic.gameobjects;

import tp1.logic.GameWorld;
import tp1.logic.Position;

public class MetalWall extends GameObject {

	public MetalWall(GameWorld game, Position pos) {
		super(game, pos);
	}

	@Override
	public boolean isSolid() {
		return true;
	}

	@Override
	public void update() {
		
	}

	@Override
	public String getIcon() {
		return "XXXXX";
	}
	@Override
	public boolean receiveInteraction(GameItem other) {
		return false;
}
}
