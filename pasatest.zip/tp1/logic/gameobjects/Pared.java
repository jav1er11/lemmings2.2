
package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;

public class Pared extends GameObject {

	WalkerRole role;
	private final boolean solido=true;
	private Position posicion;    
    public Pared (Game game, Position pos) {
		super(game, pos);
	} 	
    	  
     public boolean paredIsInposition(Position pos) {
    	 return this.posicion.equals(pos);
     }
     
     public String getIcon() {
    	 return Messages.WALL;
     }
     
     public String toString() {
    	 return this.posicion.toString()+" "+"Pared"+this.getIcon();
     }	
     public boolean isSolid() {
    	 return true;
     }
     @Override
     public void update() {
    	 
     }
     @Override
		public boolean receiveInteraction(GameItem other) {
			return other.interactWith(this);
	}
    
}