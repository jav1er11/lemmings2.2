package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.GameWorld;
import tp1.logic.Position;

public class ExitDoor extends GameObject {
	private final boolean solido=false;
	private Position posicion;
	public ExitDoor (Game game, Position pos) {
		super(game, pos);
	}
	public boolean doorIsInPos(Position pos) {
		return this.posicion.equals(pos);	
	}
	public String getIcon() {
		return"🚪";
	}
	public String toString() {
		return this.posicion.toString()+" Puerta "+this.getIcon();
	}
	public boolean isSolid() {
		return false;
	}
	@Override
	public boolean isExit() {
		return true;
	 }
	 @Override
	 public void update() {
	    	 
	 }
	 @Override
		public boolean receiveInteraction(GameItem other) {
			return other.interactWith(this);
	}
	 @Override
	 public boolean interactWith(Lemming lemming) {
			return false;
		}
}
