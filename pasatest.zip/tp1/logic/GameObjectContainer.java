package tp1.logic;

import java.util.ArrayList;
import java.util.List;

import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.lemmingRoles.LemmingRole;

public class GameObjectContainer {
	private List<GameObject> objects;

	public GameObjectContainer() {
		objects = new ArrayList<GameObject>();
	}
	
	// Only one add method (polymorphism)
	public void add(GameObject object) {
	 this.objects.add(object);
	}
	public String iconoPos(Position pos){
		String icon="";
			
		for(GameObject object: objects) {
			if(object.isInPosition(pos)) {
				icon+= object.getIcon();
			}
		}
		return icon;
	}
	public boolean isSolid(Position pos) {
	boolean found=false;
	for(GameObject object: objects) {
		found=object.isSolid()&&object.isInPosition(pos);	
		if(found) {
			return true;
		}
	}
	return false;
	}
	public boolean isSalida(Position pos) {
		boolean found=false;
		for(GameObject object: objects) {
			found=object.isExit()&&object.isInPosition(pos);	
			if(found) {
				return true;
			}
		}
	return found;
	}

	public void update() {
		int i=0;
		while(i<this.objects.size()) {
			if(!this.objects.get(i).isAlive()) {
				this.objects.get(i).incNumMuertos();
				this.objects.remove(i);		
			}
			else if(this.objects.get(i).haAcabado()) {
				this.objects.get(i).incNumSalida();
				this.objects.remove(i);			
			}
			else {
				i++;
			}
			
		}
		for (GameObject object: objects) {
				object.update();				
		}		
	}

	public boolean cambiarRole(Position pos,LemmingRole rol) {
		boolean found=false;
		for(GameObject object: objects) {
			if(object.isInPosition(pos)) {
				if(object.setRole(rol)) {
					return true;
				}	
			}		
			}
		return found;
		}
	  public boolean receiveInteractionsFrom(GameItem obj) {
		  boolean found=false;
			for(GameObject object: objects) {
				if(object.receiveInteraction(obj)) {
						found= true;			
				}			
			}
			return found;
	  }
	  
}
	

	




